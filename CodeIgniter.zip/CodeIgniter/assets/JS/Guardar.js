$("#Btn1").on('click',function Confirmar(e){
  e.preventDefault(); 
  swal({
    title: "Guardado correctamente",
    text: "Usuario modificado",
    icon: "success",
    button: "Continuar",
  }).then(function() {
window.location = "http://192.168.50.21/CodeIgniter/index.php/Usuarios/Listado";
$("#Form2").submit()
}   
});
});
