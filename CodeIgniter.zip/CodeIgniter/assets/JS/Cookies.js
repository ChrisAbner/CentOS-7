window.addEventListener("load", function() {
    window.cookieconsent.initialise({
      "palette": {
        "popup": {
          "background": "#edeff5",
          "text": "#838391"
        },
        "button": {
          "background": "#4b81e8"
        }
      },
      "theme": "classic",
      "content": {
        "message": "Este sitio web utiliza cookies para mejorar su experiencia en el sitio web.",
        "dismiss": "Entendido",
        "link": "Leer más",
        "href": "#"
      }
    })
  });