
function Cerrar() {
  swal({
      title: "¿Esta seguro?",
      text: "Recuerde memorizar su contraseña",
      icon: "warning",
      buttons: true,
      dangerMode: true,
    })
    .then((willDelete) => {
      if (willDelete) {
        swal("Hasta pronto", {
          icon: "success",
        }).then(function() {
          $("#Form2").submit();
        });
      } else {
        swal("Se ha cancelado la operacion");

      }
    });
}