      function Editar() {
        swal({
            title: "¿Esta seguro?",
            text: "Los registros no se pueden recuperar",
            icon: "warning",
            buttons: true,
            dangerMode: true,
          })
          .then((willDelete) => {
            if (willDelete) {
              swal("Se ha borrado el registro exitosamente", {
                icon: "success",
              }).then(function() {
                window.location = "http://192.168.50.21/CodeIgniter/index.php/Usuarios/Listado";
                $("#Form1").submit();
              });
            } else {
              swal("No se ha borrado ningun registro");

            }
          });
      }