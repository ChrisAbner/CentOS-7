
<?
session_start();
$token = $_POST['token'];

if ($_SESSION['token'] == $token) {
  $nombre = $_POST['nombre'];
  echo "Hola " . $nombre;
} else {
  echo "Has intentado acceder sin cumplir con el token";
}
?>
<?php
if (!$this->session->userdata("login")) {
  redirect('http://192.168.50.21/CodeIgniter/index.php/Usuarios/login');
}
?>

<!DOCTYPE html>
<html lang="es">
<?php $this->load->view('Esencial/Header');?>

<body>
  <div class="container login-container animated fadeInLeft">
    <h4 style="text-align:center">
      <?php echo ('Bienvenido '); ?>
      <?php print_r($this->session->userdata('Nombres'))?>
    </h4>
    <h4 style="text-align: center"> Añadir usuario</h4>
    <form action="Guardar_Usuario" method="POST" enctype="multipart/form-data">
      <p class="p-title-0">Nombres:</p>
      <input class="form-control form-control-md" name="Nombres" type="text" placeholder="Introduce un nombre" style="text-align: center" value="" required>
      <br>
      <p class="p-title-0">Apellidos:</p>
      <input class="form-control form-control-md" name="Apellidos" placeholder="Introduce un apellido" type="text" style="text-align: center" value="" required>
      <br>
      <p class="p-title-0">Telefono:</p>
      <input class="form-control form-control-md" name="Telefono" type="number" placeholder="Introduce un telefono" style="text-align: center" value="" required>
      <br>
      <p class="p-title-0">Usuario:</p>
      <input class="form-control form-control-md" name="Usuario" type="text" placeholder="Introduce un usuario" style="text-align: center" value="" required>
      <br>
      <p class="p-title-0">Correo:</p>
      <input class="form-control form-control-md" name="Correo" type="email" placeholder="Introduce un correo" style="text-align: center" value="" required>
      <br>
      <p class="p-title-0">Contraseña:</p>
      <input class="form-control form-control-md" name="Contrasena" type="password" placeholder="Introduce una contraseña" style="text-align: center" value="" required>
      <br>

      <div>
      </div>

      <center>
        <button class=" btn btn-lg btn btn-success" type="submit">Confirmar</button>
      </center>

    </form>
  </div>
</body>

</html>


<script src="http://192.168.50.21/CodeIgniter/assets/JS/Cookies.js"></script>
<script src="http://192.168.50.21/CodeIgniter/assets/JS/Cerrar.js"></script>